package com.example.demo;
import java.sql.SQLException;

import com.api.framework.InMemoryDBUtil;

public class SQLiteTestConnection {
	
	public static void main(String args[]) throws Exception{
		InMemoryDBUtil con=null;
		try{
		con=new InMemoryDBUtil();
		con.getInMemoryDBConnection(true);
		con.executeQueriesFromFile("queryList");
		}
		finally{
			con.closeConnection();
		}
		
	}

}

package com.api.framework;

public class MQUtility {

}
